export const generateComputerHand = () => {
  return Math.floor(Math.random() * 3);
};